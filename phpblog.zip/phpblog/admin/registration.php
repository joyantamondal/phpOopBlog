<?php
    include "Registration/inc/header.php";
    include "Registration/libs/User.php";
?>

<?php
    $user = new User();

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {//button name="submit"
        $usrRegi = $user->userRegistration($_POST);//object
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Signup Form</title>
    <link rel="stylesheet" href="../font-awesome-4.5.0/css/font-awesome.min.css">
    <style>
        body{
            margin: 0;
            padding: 0;
            background: #efefef;
            font-size: 16px;
            color: #777;
            font-family: sans-serif;
            font-weight: 300;
            background:url(../images/b.jpg);
            background-position:center;
            background-size:cover;

            /*margin:0;*/
            /*padding:0;*/
            /*height:100vh;*/
            /*background:url(../images/r2.jpg);*/
            /*background-position:center;*/
            /*background-size:cover;*/
            /*font-family:sans-serif;*/
        }

        #login-box{

            position: relative;
            margin:auto auto;
            height: 400px;
            width: 600px;
            background: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.6);
        }

        .left-box{
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            padding: 40px;
            box-sizing: border-box;
            background-image: url(../images/t3.jpg);
            background-position:center;
            background-size:cover;
        }

        h1{
            margin: 0 0 20px 0;
            font-weight: 300;
            font-size: 28px;
        }

        input[type="text"],
        input[type="password"]
        {
            display: block;
            box-sizing: border-box;
            margin-bottom: 20px;
            padding: 4px;
            width: 220px;
            height: 32px;
            border: none;
            outline: none;
            border-bottom: 1px solid #aaa;
            font-family: sans-serif;
            font-weight: 400;
            font-size: 15px;
            transition: 0.2s ease;
        }

        input[type="submit"]{
            margin-bottom: 28px;
            width: 120px;
            height: 32px;
            background: #f44336;
            border: none;
            border-radius: 2px;
            color: #fff;
            font-family: sans-serif;
            font-weight: 500;
            text-transform: uppercase;
            transform: 0.2s ease;
            cursor: pointer;
        }

        input[type="submit"]:hover,
        input[type="submit"]:focus
        {
            background: #ff5722;
            transition: 0.2s ease;
        }

       .login{
        background: white;
        width: 20%;
        font-size: 20px;
        list-style: none;
        float: right;
        text-align: center;
        font-weight: 800;

       }
       .login a{
        text-decoration: none;
        color: red;

       }

        

    </style>
</head>
<body>

<h2 style="margin-left: 50px; background: white;width: 20%;text-align: center;"><a href="../index.php">Go Back</a></h2>

<div id="login-box">

    <div class="left-box">
        <h1>Sign Up</h1>

        <?php
            if(isset($usrRegi)){
                echo $usrRegi;
            }
        ?>

        <form action="#" method="post">

            <input type="text" name="name" placeholder="Name" id=""/>
            <input type="text" name="username" placeholder="Username" id=""/>
            <input type="text" name="email" placeholder="Email" id="">
            <input type="password" name="password" placeholder="Password" id=""/>
            <input type="text" name="details" placeholder="Details" id=""/>
            <select name="role" id="select" style="padding: 9px;">
                <option>Select User Role</option>
                <option value="1">Author</option>
                <option value="2">Editor</option>
            </select>
            <br>
            <br>
            <input type="submit" name="submit" value="Sign Up">
             <li class="login"><a href="../admin/login.php" title="Click For login Me">Login</a></li>
        </form>
    </div>

   

    <div class="or">Or</div>

</div>
</body>
</html>
