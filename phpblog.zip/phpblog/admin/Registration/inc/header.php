<?php
$filepath = realpath(dirname(__FILE__));
// echo $filepath;
include_once $filepath.'/../libs/Session.php';
Session::init();

?>
