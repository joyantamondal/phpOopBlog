<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "joy");
define("TITLE", "https://selimrezaswadhin.com");
define("KEYWORDS", "PHP Tutorials, Java Tutorials, Oracle Database, C# Tutorials");
define("DESCRIPTION", "PHP Tutorials, Java Tutorials, Oracle Database, C# Tutorials");
define("AUTHORS", "Selim Reza Swadhin");
